function calcularIMC() {
    let weight = document.getElementById('peso').value;
    let height = document.getElementById('altura').value;

    let imc = weight / (height * height);

    document.getElementById('resultado').innerHTML = imc.toFixed(2);

    switch (true) {
        case (imc < 18.5):
            document.getElementById('status').innerHTML = 'Magreza';
            break;
        case (imc < 24.5):
            document.getElementById('status').innerHTML = 'Normal';
            break;
        case (imc < 30):
            document.getElementById('status').innerHTML = 'Sobrepeso';
            break;
        default:
            document.getElementById('status').innerHTML = 'Obesidade';
            break;
    }


}